# Analytical Query 

**How many movies are starting with numbers or letters**

Example: Starting with 1/2/3.. and /A/B/C..Z

Run the following code to view output

```
sh execute.sh
```
