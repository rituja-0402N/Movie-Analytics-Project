# Analytical Query

**Find the distinct genres present in the dataset**

Run the following code to view output

```
sh execute.sh
```
