# Analytical Query 

**Find the list of latest released movies**

Run the following code to view output

```
sh execute.sh
```
