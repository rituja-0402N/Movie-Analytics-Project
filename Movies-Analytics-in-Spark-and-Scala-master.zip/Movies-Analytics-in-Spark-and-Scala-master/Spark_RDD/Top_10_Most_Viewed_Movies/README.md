# Analytical Query

**Find the Top 10 most viewed movies**

Run the following code to view output

```
sh execute.sh
```
