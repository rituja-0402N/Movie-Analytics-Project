# Analytical Query 

**What is the total rating For each movie?**

Run the following code to view output

```
sh execute.sh
```
