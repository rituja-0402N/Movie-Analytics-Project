# Analytical Query 

**Find the list of oldest released movies**

Run the following code to view output

```
sh execute.sh
```
