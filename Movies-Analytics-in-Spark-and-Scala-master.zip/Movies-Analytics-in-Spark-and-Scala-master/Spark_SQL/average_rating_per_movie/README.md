# Analytical Query 

**What is the average rating for each movie?**

Run the following code to view output

```
sh execute.sh
```
