# Analytical Query 

**How many users rated each movie?**

Run the following code to view output

```
sh execute.sh
```
