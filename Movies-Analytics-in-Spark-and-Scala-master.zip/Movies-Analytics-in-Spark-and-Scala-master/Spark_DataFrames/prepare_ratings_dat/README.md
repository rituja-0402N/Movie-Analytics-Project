# Analytical Query

**Prepare ratings.data: Loading a double delimited csv file into a Dataframe and specifying the schema programmatically**

Run the following command in terminal
```
sh execute.sh
```
