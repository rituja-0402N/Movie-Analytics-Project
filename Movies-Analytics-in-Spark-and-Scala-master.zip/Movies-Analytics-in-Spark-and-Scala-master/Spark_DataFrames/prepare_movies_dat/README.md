# Analytical Query

**Prepare Movies.data: Cleaning delimited data & Extracting the Year and Genre from movies.dat**

Run the following command in terminal
```
sh execute.sh
```
